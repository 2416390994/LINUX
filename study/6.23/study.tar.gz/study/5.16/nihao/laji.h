void fun ();
