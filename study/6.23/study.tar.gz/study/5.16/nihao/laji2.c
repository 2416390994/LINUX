#include<stdio.h>
#include "laji.h"
void fun ()
{
printf ("你好呀！\n");
}
