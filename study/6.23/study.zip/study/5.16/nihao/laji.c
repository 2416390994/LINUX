#include <stdio.h>
#include<stdlib.h>
#include "laji.h"
int main()
{
fun();
return 0; 
}
