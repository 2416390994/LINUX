#include <stdio.h>

int main()
{

    printf("%c%X%X\n", 'C', '+', '+');
    return 0;
}
