#include "udpsocket.hpp"

int main(int argc, char *argv[])
{
    if (argc != 3) {
        printf("./udp_srv ip port\n");
        return -1;
    }
    std::string srv_ip = argv[1];
    uint16_t srv_port = atoi(argv[2]);

    UdpSocket sock;

    CHECK_RET(sock.Socket());
    CHECK_RET(sock.Bind(srv_ip, srv_port));

    while(1) {
        std::string cli_ip;
        uint16_t cli_port;
        std::string buf;
        sock.Recv(buf, cli_ip, cli_port);
        printf("client[%s:%d]--say:%s\n", cli_ip.c_str(), cli_port,
                buf.c_str());

        buf.clear();
        printf("server say:");
        fflush(stdout);
        std::cin >> buf;
        sock.Send(buf, cli_ip, cli_port);
    }
    sock.Close();
    return 0;
}
